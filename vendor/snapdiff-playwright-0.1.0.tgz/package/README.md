# @snapdiff/playwright

SnapDiff visual regression for Playwright. Captures PNGs during your tests, ships them to SnapDiff, gates merges on visual changes.

Designed to be a thin layer: it doesn't replace your test runner, your assertions, or your auth setup. You add `await snapshot(page, 'name')` wherever you want a visual check, and the reporter handles upload, build creation, polling, and gating.

## Why this and not just URL captures

The URL-based [SnapDiff GitHub Action](https://github.com/corralimited/snapdiff/tree/main/github-action) works great for marketing sites, docs, and any unauthenticated route. For authenticated routes inside your app, it can't see past the login screen.

The Playwright reporter solves that by piggybacking on your existing E2E tests:
- Your tests already log in (via `storageState`, OAuth, or login flow)
- You add one line per page you want a visual snapshot of
- Reporter captures the page in the authenticated state and ships it

You can use both: keep the GitHub Action for `/`, `/pricing`, etc., and use this reporter for `/dashboard`, `/account`, etc. — all inside one SnapDiff project.

## Install

```bash
npm install -D @snapdiff/playwright
# or
pnpm add -D @snapdiff/playwright
# or
yarn add -D @snapdiff/playwright
```

Requires `@playwright/test` 1.40+.

## Configure the reporter

Add it to `playwright.config.ts`:

```ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [
    ['list'],
    [
      '@snapdiff/playwright/reporter',
      {
        project: 'my-app',                    // your SnapDiff project slug
        // apiKey: process.env.SNAPDIFF_API_KEY,   // defaults to SNAPDIFF_API_KEY
        // apiUrl: 'https://snapdiff.example.com', // self-hosted? set this
      },
    ],
  ],
});
```

## Capture in tests

```ts
import { test, expect } from '@playwright/test';
import { snapshot } from '@snapdiff/playwright';

test('account page renders correctly', async ({ page }) => {
  await page.goto('/account');
  await expect(page.locator('h1')).toBeVisible();
  await snapshot(page, 'account');
});

test('billing settings render correctly', async ({ page }) => {
  await page.goto('/account/billing');
  await snapshot(page, 'account-billing');
});
```

Names must be unique across the entire test run — they map directly to baselines in SnapDiff. Use prefixes if you need to organize (`account-overview`, `account-billing`, `settings-profile`).

### Snapshot options

```ts
await snapshot(page, 'dashboard', {
  fullPage: true,                                 // capture entire scrollable page
  selector: '[data-testid="main-content"]',       // capture only this element
  clip: { x: 0, y: 0, width: 1280, height: 720 }, // explicit region
  delayMs: 500,                                   // wait before capture (animations)
});
```

## How auth works (no extra setup required)

The reporter doesn't handle login itself. Your existing Playwright auth setup does:

```ts
// playwright.config.ts
export default defineConfig({
  use: {
    storageState: 'auth.json', // already-logged-in state
  },
});
```

```ts
// global setup (one-time login)
test.beforeAll(async ({ browser }) => {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto('/login');
  await page.fill('[name=email]', process.env.TEST_USER_EMAIL!);
  await page.fill('[name=password]', process.env.TEST_USER_PASSWORD!);
  await page.click('button[type=submit]');
  await page.waitForURL('/dashboard');
  await ctx.storageState({ path: 'auth.json' });
});
```

Whatever auth your tests already use — cookies, localStorage tokens, OAuth — the reporter inherits. There's no separate auth concept in SnapDiff.

## Reporter options

| Option | Type | Default | Description |
| --- | --- | --- | --- |
| `project` | `string` | (required) | SnapDiff project slug or id |
| `apiKey` | `string` | `process.env.SNAPDIFF_API_KEY` | API key |
| `apiUrl` | `string` | `https://api.snapdiff.dev` | Override for self-hosted |
| `branch` | `string` | auto-detected | Override CI detection |
| `commitSha` | `string` | auto-detected | Override CI detection |
| `commitMessage` | `string` | auto-detected | Override CI detection |
| `pullRequestUrl` | `string` | auto-detected | Override CI detection |
| `wait` | `boolean` | `true` | Poll the build until done; fail the run on visual changes |
| `waitTimeoutMinutes` | `number` | `5` | Cap polling duration |
| `disabled` | `boolean` | `false` | No-op the reporter (useful for local debugging) |

## CI integration

The reporter auto-detects CI metadata for GitHub Actions, CircleCI, GitLab CI, Vercel, and Buildkite. For other systems, pass explicit overrides via reporter options.

### GitHub Actions example

```yaml
# .github/workflows/visual.yml
name: Visual diff

on:
  pull_request:
  push:
    branches: [main]

jobs:
  visual:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - run: npm ci
      - run: npx playwright install --with-deps chromium
      - run: npx playwright test
        env:
          SNAPDIFF_API_KEY: ${{ secrets.SNAPDIFF_API_KEY }}
          # If your tests need credentials to log in:
          TEST_USER_EMAIL: ${{ secrets.TEST_USER_EMAIL }}
          TEST_USER_PASSWORD: ${{ secrets.TEST_USER_PASSWORD }}
```

The reporter creates a build, waits for diffs to finish, and exits non-zero if any snapshot changed. Configure branch protection on `main` requiring the workflow check to pass, and you've got a merge gate on visual regressions.

## How it works

1. Your tests run normally. `await snapshot(page, name)` calls `page.screenshot()` and attaches the PNG to the test result.
2. After each passing test, the reporter uploads attached PNGs to `POST /v1/screenshot/upload`. SnapDiff returns a `screenshot_id`.
3. After the entire test run, the reporter creates a build via `POST /v1/projects/:project/builds` referencing those `screenshot_id`s.
4. The reporter polls until the build finishes diffing. If any page changed, it returns `status: 'failed'` to Playwright, which exits non-zero.

There's no DOM serialization, no cloud rendering. Pixels are captured on your CI machine, diffed by SnapDiff. This is deliberate — see [POSITIONING.md](https://github.com/corralimited/snapdiff/blob/main/docs/POSITIONING.md).

## Troubleshooting

**"No snapshots captured"** — you registered the reporter but didn't call `snapshot()` anywhere. Add `await snapshot(page, 'name')` inside a test that passes.

**"Duplicate snapshot names"** — two tests captured a snapshot with the same name. Names are global. Rename or namespace.

**"No API key found"** — set `SNAPDIFF_API_KEY` in the environment, or pass `apiKey` in reporter options.

**"Build poll failed"** — usually transient. Check Railway worker logs if persistent. The reporter retries upload but not poll; rerun the test job.

**Authenticated routes show login form** — your `storageState` isn't loaded. Confirm `playwright.config.ts` has `use.storageState` pointing at a valid auth state file, and that file is generated before `playwright test` runs.

## License

MIT
